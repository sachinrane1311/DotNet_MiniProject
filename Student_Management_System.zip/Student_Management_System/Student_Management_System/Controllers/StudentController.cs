﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace Student_Management_System.Controllers
{
    public class StudentController
    {
        internal void StudentRole()
        {
            Boolean flag = true;
            while (flag)
            {

            Console.WriteLine("-----------------------------");
            Console.WriteLine("    Student Logged In !!!    ");
            Console.WriteLine("-----------------------------");

            Console.WriteLine("1-showDetails\n2-updateDetails\n3-Logout");
            
            Console.WriteLine("-----------------------------");

                int option = Convert.ToInt32(Console.ReadLine());

                switch (option)
                {
                    case 1:
                        Console.WriteLine("Show Details");
                        showDetails();
                        break;

                    case 2:
                        Console.WriteLine("Update Details");
                        updateDetails();
                        break;

                    case 3:
                        Console.WriteLine("Logout !!!");
                        flag = false;
                        break;

                }

            }
        }


        private void updateDetails()
        {
            Console.WriteLine("samadhan has to complete this task");
        }

        private void showDetails()
        {
            Console.WriteLine("sanket has to complete this task");
        }
    }

}
