﻿using Student_Management_System.DataBaseContext;
using Student_Management_System.Models;
using System;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace Student_Management_System.Controllers
{
    class AdminController
    {
        public static void AdminRole()
        {
            Boolean flag = true;
            while (flag)
            {
                Console.WriteLine("-----------------------------");
                Console.WriteLine("     Admin Logged In !!!     ");
                Console.WriteLine("-----------------------------");


                Console.WriteLine("1-Add_Student\n2-Delete_Student\n3-Update_Student\n4-Show_All_Students\n5-Logout");
                Console.WriteLine("-----------------------------");

                int option = Convert.ToInt32(Console.ReadLine());

                switch (option)
                {
                    case 1:
                        Console.WriteLine("Add Student");

                        Console.Write("Name : ");
                        string sname = Console.ReadLine();
                        Console.Write("Email : ");
                        string semail = Console.ReadLine();
                        Console.Write("Password : ");
                        string spassword = Console.ReadLine();
                        Console.Write("Course : ");
                        string scourse = Console.ReadLine();
                        //addStud.user.name = sname;
                        //addStud.user.email = semail;
                        //addStud.user.password = spassword;
                        //addStud.course = scourse;
                        //Console.WriteLine(addStud.ToString());
                        //addStudent(addStud);
                        
                        break;

                    case 2:
                        Console.WriteLine("Delete Student");
                        deleteStudent();
                        break;

                    case 3:
                        Console.WriteLine("Update Student");
                        Console.WriteLine("--------------");
                        Console.WriteLine("Student Id :");
                        int id = Convert.ToInt32(Console.ReadLine());

                        Console.WriteLine("New Name :");

                        String newName = Console.ReadLine();

                        User usr = new User();
                        usr.name = newName;

                        updateStudent(usr,id);
                        break;

                    case 4:
                        Console.WriteLine("Show All Students");
                        showAll();
                        break;

                    case 5:
                        Console.WriteLine("Logout !!!");
                        flag = false;
                        break;

                }
            }
        }

        private static void showAll()
        {
            Console.WriteLine("***All Users Data***");
            SmsDbContext ctx = new();
            var Data = from s in ctx.Users
                              select s;
            foreach (var item in Data)
            {

                Console.WriteLine(item.userID + " " + item.name + " " + item.email);
            }
            //Console.WriteLine("Samiksha will work on this");
        }

        private static void updateStudent(User data, int id)
        {
            SmsDbContext ctx = new();
            User row = ctx.Users.First(x => x.userID == id);
            row.name = data.name;
            ctx.Update(row);
            ctx.SaveChanges();
             Console.WriteLine(row.userID + " Updated !!!!");
            // Console.WriteLine("Samiksha will work on this");
        }

        private static void deleteStudent()
        {
            SmsDbContext ctx = new();
            Console.WriteLine("Sameena will work on this");
        }

        private static void addStudent(String studentName, String studentEmail, String studentPassword, String course)
        {
            SmsDbContext ctx = new();

            Student stud = new Student();
            User user = new User();

            user.name = studentName;
            //stud.name = studentName;
            user.email = studentEmail;
            user.password = studentPassword;
            user.role = "Student";

            stud.course = course;
            user.student = stud;
            ctx.Users.Add(user);

            stud.course = course;

            ctx.Students.Add(stud);
            ctx.SaveChanges();

            Console.WriteLine(" Student Added !!!!");
            Console.WriteLine("Sameena will work on this");
        }


        public void AddAdmin()
        {
            SmsDbContext ctx = new SmsDbContext();
            User admn = new User();
            admn.name = "admin";
            admn.email = "admin@gmail.com";
            admn.password = "12345";
            admn.role = "Admin";

            ctx.Users.Add(admn);
            ctx.SaveChanges();
        }
    }
}